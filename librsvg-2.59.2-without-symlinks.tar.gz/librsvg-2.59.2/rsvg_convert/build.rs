fn main() {
    system_deps::Config::new().probe().unwrap();
}
