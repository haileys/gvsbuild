To report security bugs, and to view a list of releases with security
fixes, please see
https://gnome.pages.gitlab.gnome.org/librsvg/devel-docs/security.html
which is part of the development guide for librsvg.

The source for that page is at
https://gitlab.gnome.org/GNOME/librsvg/-/blob/main/devel-docs/security.rst
which is the `devel-docs/security.rst` in this repository.
