# librsvg-rebind

See [librsvg-rebind/README.md] for the use cases of these crates.

## Regenerate bindings

To regenerate the bindings you can call `./regen.sh` after running `git submodule update --init --recursive`.
