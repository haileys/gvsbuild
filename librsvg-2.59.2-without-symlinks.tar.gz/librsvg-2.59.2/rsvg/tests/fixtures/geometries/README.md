The files in this directory come from the [Horizon EDA][horizon]
project, an electronics design tool.  Please see the comments in [the
relevant tests][tests] for an explanation of how these files are
used.

[horizon]: https://github.com/horizon-eda/horizon/
[tests]: ../../tests/src/geometries.rs
