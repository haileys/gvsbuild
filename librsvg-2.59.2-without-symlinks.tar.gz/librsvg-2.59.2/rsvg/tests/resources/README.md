# Font for librsvg's test suite

The files here provide a reproducible set of fonts for librsvg's test suite.

The Ahem font is from the Web Platform tests:
https://web-platform-tests.org/writing-tests/ahem.html - It is a font with fully square
glyphs.

Noto Sans Hebrew: https://fonts.google.com/noto/specimen/Noto+Sans+Hebrew
